from tkinter import *
import sqlite3


root = Tk()
root.title('MTG Catalog')
root.geometry("350x300")

# Make the Card Database
conn = sqlite3.connect('card_catalog.db')

# Database Cursor
c = conn.cursor()

# Create Database Table
# c.execute("""CREATE TABLE card_table (c_name text, c_condition text, price real)""")

# Button Functions

def submit():
    # Connect to the database and make cursor
    conn = sqlite3.connect('card_catalog.db')
    c = conn.cursor()

    #Insert Data Into Table
    c.execute("INSERT INTO card_table VALUES (:c_name, :c_condition, :price)",
              {
                  'c_name': c_name.get(),
                  'c_condition': c_condition.get(),
                  'price': price.get()
              })

    # Commit and Close
    conn.commit()
    conn.close()

    # Clear the Text Boxes
    c_name.delete(0, END)
    c_condition.delete(0, END)
    price.delete(0, END)

def query():
    # Connect to the database and make cursor
    conn = sqlite3.connect('card_catalog.db')
    c = conn.cursor()

    #Query the Database
    c.execute("SELECT *, oid FROM card_table")
    records = c.fetchall()

    # Read through results

    print_records = ''
    for record in records:
        print_records += str(record) + "\n"

    # Label that displays the query

    query_label = Label(root , text=print_records)
    query_label.grid(row=8, column=0, columnspan=2)

    # Commit and Close
    conn.commit()
    conn.close()

# Text Boxes

c_name = Entry(root, width=30)
c_name.grid(row=0, column=1, padx=20)
c_condition = Entry(root, width=30)
c_condition.grid(row=1, column=1)
price = Entry(root, width=30)
price.grid(row=2, column=1)

# Labels
c_name_label = Label(root, text="Card Name")
c_name_label.grid(row=0, column=0)
c_condition_label = Label(root, text="Card Condition")
c_condition_label.grid(row=1, column=0)
price_label = Label(root, text="Card Price")
price_label.grid(row=2, column=0)

# Submit Button
submit_btn = Button(root, text="Add to Card Catalog", command=submit)
submit_btn.grid(row=6, column=0, columnspan=2, pady=10, padx=10, ipadx=100)

# Query Button
query_btn = Button(root, text="Show Card Collection", command=query)
query_btn.grid(row=7, column=0, columnspan=2, pady= 10, padx=10, ipadx=100)

# Commit Changes
conn.commit()

# Close Connection
conn.close()

root.mainloop()