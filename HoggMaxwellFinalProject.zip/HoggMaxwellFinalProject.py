from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import sqlite3

root = Tk()
root.title('MTG Catalog')
root.geometry("335x360")

# Make the Card Database
conn = sqlite3.connect('card_catalog.db')

# Database Cursor
c = conn.cursor()

# Database Table Check: If the table doesn't exist, it will be created.
c.execute("""CREATE TABLE if not exists card_table (c_name text, c_condition text, price real)""")

# Button Functions
# Function to add a card to the collection
def submit():

    # Validates input for Quality is one of the desired input
    quality = c_quality.get()
    while quality != "NM" and quality != "LP" and quality != "MP" and quality != "HP" and quality != "DMG":
        error_label.config(text="Error: Quality must be NM, LP, , MP, HP, or DMG!")
        c_name.delete(0, END)
        c_quality.delete(0, END)
        c_price.delete(0, END)
        return

    # This validates that the input for price is a float.
    try:
        float(c_price.get())
    except ValueError:
        error_label.config(text="Error: Price must be a digit!")
        c_name.delete(0, END)
        c_quality.delete(0, END)
        c_price.delete(0, END)
        return

    # Clears error test when none are present
    error_label.config(text="")

    # Connect to the database and make cursor
    conn = sqlite3.connect('card_catalog.db')
    c = conn.cursor()

    # Insert Data Into Table
    c.execute("INSERT INTO card_table VALUES (:c_name, :c_quality, :price)",
              {
                  'c_name': c_name.get(),
                  'c_quality': c_quality.get(),
                  'price': c_price.get()
              })

    # Commit and Close
    conn.commit()
    conn.close()

    # Clear the Text Boxes
    c_name.delete(0, END)
    c_quality.delete(0, END)
    c_price.delete(0, END)

# Function to view the collection in a new window
def query():

    # Create a new Window for the collection
    newWindow = Toplevel()
    newWindow.title("Your collection")
    newWindow.geometry("400x250")

    # Make frame for Treeview
    tree_frame = Frame(newWindow)
    tree_frame.pack(pady=10)

    # Create Scrollbar
    tree_scroll = Scrollbar(tree_frame)
    tree_scroll.pack(side=RIGHT, fill=Y)

    # Create Treeview
    my_tree = ttk.Treeview(tree_frame, yscrollcommand=tree_scroll.set, selectmode="extended")
    my_tree.pack()

    # Configure Scrollbar
    tree_scroll.config(command=my_tree.yview)

    # Define Columns
    my_tree['columns'] = ("Card ID", "Card Name", "Quality", "Card Price")

    # Configure Columns
    my_tree.column("#0", width=0, stretch=NO)
    my_tree.column("Card ID", anchor=CENTER, width=30)
    my_tree.column("Card Name", anchor=W, width=200)
    my_tree.column("Quality", anchor=CENTER, width=50)
    my_tree.column("Card Price", anchor=E, width=70)

    # Create Headings
    my_tree.heading("#0", text='', anchor=W)
    my_tree.heading("Card ID", text="ID", anchor=CENTER)
    my_tree.heading("Card Name", text="Card Name", anchor=W)
    my_tree.heading("Quality", text="Quality", anchor=CENTER)
    my_tree.heading("Card Price", text="Card Price", anchor=E)

    # Striped Rows
    my_tree.tag_configure('oddrow', background="white")
    my_tree.tag_configure('evenrow', background="lightblue")


    # Connect to the database and make cursor
    conn = sqlite3.connect('card_catalog.db')
    c = conn.cursor()

    # Query the Database
    c.execute("SELECT *, oid FROM card_table")
    data = c.fetchall()

    # Add Data to Table
    global count  # Count that controls if the row will be white or lightblue
    count = 0

    # Loop that alternates colors of row for the table.
    for record in data:
        if count % 2 == 0:
            my_tree.insert(parent='', index='end', iid=count, text='', values=(record[3], record[0], record[1], record[2]),
                           tags=('evenrow',))

        else:
            my_tree.insert(parent='', index='end', iid=count, text='', values=(record[3], record[0], record[1], record[2]),
                           tags=('oddrow',))
        count += 1



    # Commit changes
    conn.commit()
    # Close Connection
    conn.close()

# Function that deletes cards from the catalog
def delete():

    # connect to Database
    conn = sqlite3.connect('card_catalog.db')
    c = conn.cursor()

    # Query the database for validation purposes
    c.execute("SELECT *, oid FROM card_table")
    iD_data = c.fetchall()

    # Creates a list of valid ID's to validate against.
    valid_Id = []
    for record in iD_data:
        valid_Id.append(record[3])

    # Convert the input to int to compare against valid IDs
    delete_id = int(delete_box.get())
    if delete_id in valid_Id:

        # Deletes the Card
        c.execute("DELETE from card_table WHERE oid= " + delete_box.get())
        delete_box.delete(0, END)

    else:
        # Messagebox pops up informing the user of their error
        messagebox.showinfo("Error!", "Card ID not found in Collection. Double check ID #'s.")
        delete_box.delete(0, END)
        return


    # Commit Changes
    conn.commit()
    # Close Connection
    conn.close()

# Function that closes the program
def exit():
    root.destroy()

# Function that refreshes the total value of the collection
def refresh():

    # Connect to Database
    conn = sqlite3.connect('card_catalog.db')
    # Create Cursor
    c = conn.cursor()

    # Query the database
    c.execute("SELECT *, oid FROM card_table")
    valueData = c.fetchall()  # This places the info from the database into a list

    overallValue = 0  # The overall value of the collection

    # this loop goes through the list and adds their values together.
    for value in valueData:
        overallValue += float(value[2])
    strOverallValue = str(overallValue)
    value_label = Label(root, text="Total Collection Value is $" + strOverallValue)
    value_label.grid(row=12, column=0, columnspan=2)

    # Commit Changes
    conn.commit()
    # Close Connection
    conn.close()

# Text Boxes

c_name = Entry(root, width=30)
c_name.grid(row=0, column=1, padx=20)
c_quality = Entry(root, width=30)
c_quality.grid(row=1, column=1)
c_price = Entry(root, width=30)
c_price.grid(row=3, column=1)
delete_box = Entry(root, width=30)
delete_box.grid(row=8, column=1)

# Labels
c_name_label = Label(root, text="Card Name")
c_name_label.grid(row=0, column=0)
c_quality_label = Label(root, text="Card Quality")
c_quality_label.grid(row=1, column=0)
qualityGuide_label = Label(root, text="NM, LP, MP, HP, or DMG")
qualityGuide_label.grid(row=2, column=1)
price_label = Label(root, text="Card Price")
price_label.grid(row=3, column=0)
delete_box_label = Label(root, text= "Enter Card ID #")
delete_box_label.grid(row=8, column=0)
error_label = Label(root, text="")
error_label.grid(row=11, column=0, columnspan=2)

# Overall Value Label
c.execute("SELECT *, oid FROM card_table")
valueData = c.fetchall()
overallValue = 0
for value in valueData:
    overallValue += float(value[2])
strOverallValue = str(overallValue)
value_label = Label(root, text="Total Collection Value is $" + strOverallValue)
value_label.grid(row=12, column=0, columnspan=2)

# Buttons
# Submit Button
submit_btn = Button(root, text="Add to Card Catalog", command=submit)
submit_btn.grid(row=7, column=0, columnspan=2, pady=10, padx=10, ipadx=100)

# Query Button
query_btn = Button(root, text="Show Card Collection", command=query)
query_btn.grid(row=10, column=0, columnspan=2, pady=10, padx=10, ipadx=97)

# Delete Button
delete_btn = Button(root, text="Delete Card from Collection", command=delete)
delete_btn.grid(row=9, column=0, columnspan=2, pady=10, padx=10, ipadx=80)

# Refresh Total Button
refresh_btn = Button(root, text="Refresh Total", command=refresh)
refresh_btn.grid(row=13, column=0, columnspan=2)

# Exit Button
exit_btn = Button(root, text="Exit MTGCatalog", command=exit)
exit_btn.grid(row=14, column=0, columnspan=2, pady=10)

# Commit Changes
conn.commit()

# Close Connection
conn.close()


# Runs the GUI
root.mainloop()
